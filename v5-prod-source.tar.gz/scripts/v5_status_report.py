#!/usr/bin/env python3
"""
Generate a concise production status report for the V5 workspace.
"""

from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional

WORKSPACE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WORKSPACE))

REPORTS_DIR = WORKSPACE / "reports"
RUNS_DIR = REPORTS_DIR / "runs"
ORDERS_DB = REPORTS_DIR / "orders.sqlite"


def resolve_config_path() -> Path:
    env_cfg = (os.getenv("V5_CONFIG") or "").strip()
    if env_cfg:
        path = Path(env_cfg)
        if not path.is_absolute():
            path = WORKSPACE / path
        return path

    for candidate in ("configs/live_prod.yaml", "configs/live_20u_real.yaml", "configs/config.yaml"):
        path = WORKSPACE / candidate
        if path.exists():
            return path

    return WORKSPACE / "configs/live_prod.yaml"


CONFIG_PATH = resolve_config_path()


def load_config() -> Dict[str, Any]:
    try:
        import yaml

        return yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}


def get_latest_run_data() -> Optional[Dict[str, Any]]:
    if not RUNS_DIR.exists():
        return None

    run_dirs = [path for path in RUNS_DIR.iterdir() if path.is_dir() and (path / "decision_audit.json").exists()]
    if not run_dirs:
        return None

    latest_dir = max(run_dirs, key=lambda path: path.stat().st_mtime)
    try:
        return json.loads((latest_dir / "decision_audit.json").read_text(encoding="utf-8"))
    except Exception:
        return None


def get_service_status() -> str:
    try:
        for unit in ("v5-prod.user.service", "v5-live-20u.user.service"):
            result = subprocess.run(
                ["systemctl", "--user", "is-active", unit],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return "running"
        return "stopped"
    except Exception:
        return "unknown"


def check_borrow_status() -> Dict[str, Any]:
    cfg = load_config()
    execution_cfg = cfg.get("execution", {}) if isinstance(cfg, dict) else {}

    blacklist_file = REPORTS_DIR / "auto_blacklist.json"
    entries = []
    if blacklist_file.exists():
        try:
            payload = json.loads(blacklist_file.read_text(encoding="utf-8"))
            entries = payload.get("entries", []) if isinstance(payload, dict) else []
        except Exception:
            entries = []

    return {
        "config": {
            "liab_eps": execution_cfg.get("borrow_liab_eps", 0.01),
            "neg_eq_eps": execution_cfg.get("borrow_neg_eq_eps", 0.01),
            "mode": execution_cfg.get("borrow_block_mode", "symbol_only"),
        },
        "blacklist_count": len(entries),
        "blacklist_symbols": [item.get("symbol") for item in entries[:5] if isinstance(item, dict)],
    }


def get_last_filled_trade_ts() -> Optional[str]:
    if not ORDERS_DB.exists():
        return None

    try:
        conn = sqlite3.connect(str(ORDERS_DB))
        row = conn.execute("SELECT MAX(created_ts) FROM orders WHERE state='FILLED'").fetchone()
        conn.close()
        ts_ms = row[0] if row else None
        if not ts_ms:
            return None
        return datetime.fromtimestamp(ts_ms / 1000).isoformat(timespec="minutes")
    except Exception:
        return None


def build_next_run_hint() -> str:
    next_run = datetime.now().replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    return next_run.strftime("%Y-%m-%d %H:%M")


def generate_report() -> str:
    cfg = load_config()
    run_data = get_latest_run_data() or {}
    borrow = check_borrow_status()
    service_status = get_service_status()
    last_trade = get_last_filled_trade_ts() or "n/a"
    budget_cap = cfg.get("budget", {}).get("live_equity_cap_usdt", "n/a") if isinstance(cfg, dict) else "n/a"

    counts = run_data.get("counts", {}) if isinstance(run_data, dict) else {}
    notes = run_data.get("notes", []) if isinstance(run_data, dict) else []
    drawdown_note = next((note for note in notes if isinstance(note, str) and "drawdown" in note.lower()), "n/a")

    return "\n".join(
        [
            "V5 Status Report",
            f"time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"workspace: {WORKSPACE}",
            f"config: {CONFIG_PATH.name}",
            "",
            "System",
            f"- live_service: {service_status}",
            f"- live_equity_cap_usdt: {budget_cap}",
            f"- next_expected_run: {build_next_run_hint()}",
            "",
            "Borrow Guard",
            f"- liab_eps: {borrow['config']['liab_eps']}",
            f"- neg_eq_eps: {borrow['config']['neg_eq_eps']}",
            f"- mode: {borrow['config']['mode']}",
            f"- blacklist_count: {borrow['blacklist_count']}",
            f"- blacklist_symbols: {borrow['blacklist_symbols']}",
            "",
            "Latest Run",
            f"- regime: {run_data.get('regime', 'n/a')}",
            f"- selected: {counts.get('selected', 'n/a')}",
            f"- targets_pre_risk: {counts.get('targets_pre_risk', 'n/a')}",
            f"- orders_rebalance: {counts.get('orders_rebalance', 'n/a')}",
            f"- drawdown_note: {drawdown_note}",
            f"- last_filled_trade: {last_trade}",
        ]
    )


def main() -> int:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    report = generate_report()
    print(report)
    output = REPORTS_DIR / f"status_report_{datetime.now().strftime('%Y%m%d_%H%M')}.txt"
    output.write_text(report, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
