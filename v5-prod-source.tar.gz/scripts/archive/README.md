﻿# Scripts Archive

This directory holds non-production scripts that are intentionally kept out of the active `scripts/` root.

## Current archive split

- `research/`: backtests, factor analysis, walk-forward experiments, training, and evaluation helpers
- `devtools/`: one-off codebase maintenance helpers
- `legacy/`: old launch scripts and superseded 20u automation
- root `scripts/archive/`: older historical archives that were already moved before this cleanup pass

## Why files are archived instead of deleted

- They are not part of the current production runtime.
- Some may still be useful for offline investigation or historical reference.
- Moving them out of `scripts/` reduces ambiguity when operating the live system.

## Usage rule

If an archived script is ever needed again, move it back into an active location or call it with an explicit path after reviewing its assumptions and config defaults.
